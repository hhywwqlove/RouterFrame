package com.router.android.creater;

/**
 * Created by WeiqiangWang on 17/5/11.
 */

public class MethodUrlCreater {
}
